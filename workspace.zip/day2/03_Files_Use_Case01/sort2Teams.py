import os
import shutil

# A information source that contains the students to teams.
# This information could be stored in Excel file also.
teamDict = {"Team 1":[121001,121002,121003,121004,121005],
"Team 2":[121006,121007,121008,121009,121010],
"Team 3":[121011,121012,121013,121014,121015],
"Team 4":[121016,121017,121018,121019,121020],
"Team 5":[121021,121022,121023,121024,121025]}

for team in teamDict:
	os.mkdir(team) # Create the subfolders - "Team 1", "Team 2"...
	for student in teamDict[team]:
		path = "student " + str(student)
		if os.path.isdir(path): #Checking if the student folder exists, e.g. student did not submit
			shutil.move(path, team)
		else:
			print(path + " does not exist")
	
print("Completed")
