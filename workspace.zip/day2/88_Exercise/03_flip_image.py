#
#There's a flipped image in the img folder, which could it be?
#Rectify it and saved the resultant image
#

import os
from PIL import Image, ImageFilter, ImageOps

filename = "FIX_ME"            #Input

#hint: there is an image that looks inverted/flipped in the img folder
im = Image.open(filename)

out = im.transpose(FIX_ME)     #process

im.save("rotated_image.jpg")   #output