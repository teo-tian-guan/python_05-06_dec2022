def getLongerName(name1, name2):
    if len(name1) > len(name2):
        return FIX_ME
    else:
        return FIX_ME


names = ["Josephine", "Marianne", "Michaleangelo"]

#assume longest name is the first item 
longest = names[0]

name = names[0]
longest = getLongerName(longest, name)

name = names[1]
longest = getLongerName(longest, name)

name = names[FIX_ME]
longest = getLongerName(longest, name)

print ("Longest word is : " + FIX_ME)