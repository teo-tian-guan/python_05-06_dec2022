"""
Task
Open the text file named "items.txt" location in the folder "data_files"
It will then write into a file named "receipt.txt"

The expected receipt looks like the following:

             ABC Pte Ltd
APPLES                    $      5.50
BOOKS                     $     20.00
PINEAPPLE                 $      6.00
POPCORD                   $     10.00
                           ==========
                          $     41.50

"""
#------------------------

fin = open(FIX_ME)

items = []
prices = []

for i in fin:
    name = i.split(FIX_ME)[0]
    price = float(FIX_ME)
    items.append(name)
    prices.FIX_ME

fout = open(FIX_ME)


company = "ABC Pte Ltd"
line = " " * (18-len(company)//2) + company

fout.write(line)
fout.write("\n")

for i in range(len(items)):
    line = "%-25s $%10.2f\n" % (FIX_ME)
    fout.FIX_ME

line = " " * 27 + "=" * 10 + "\n"
fout.write(line)
line = " " * 26  + "$FIX_ME" % (sum(prices)) + "\n"
fout.write(line)
fout.close()