#
#Pick any image in the img folder, convert it into a grayscale image
#It will then save the resultant image
#

import os
from PIL import Image, ImageFilter, ImageOps

filename = "FIX_ME"

im = Image.open(filename)

out = ImageOps.FIX_ME

im.show()
out.show()

#name it as "converted_image.jpg"
im.save(FIX_ME)