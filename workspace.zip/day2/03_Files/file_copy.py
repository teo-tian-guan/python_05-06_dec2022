import shutil

# copy file, destination must exist
shutil.copy("hello.txt", "folder1")

# recursively copy an entire directory
# error if the destination folder already exist
shutil.copytree("folder1", "folder_to_delete")
shutil.copytree("folder1", "folder_to_delete2")

# move file, destination must exist
shutil.move("folder1/hello.txt","folder2")

# move and rename file
shutil.move("folder_to_delete/hello.txt","folder_to_delete2/newhello.txt")

