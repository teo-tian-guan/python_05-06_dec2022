# 1. Defining the function
def get_discount(price, discount):
    return price * (1 - discount/100)

# 2. Calling the function
print(get_discount(100, 10))
