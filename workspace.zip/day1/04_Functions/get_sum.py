# 1. Defining the function
def get_sum(numbers):
    total = 0
    for number in numbers: 
        total = total + number
        
    return total

# 2. Calling the function
s1 = get_sum([2, 5, 8, 3])
print(s1)